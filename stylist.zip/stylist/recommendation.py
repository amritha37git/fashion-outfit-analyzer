import itertools

from .color_match import colors_match


# ==========================================================
# OCCASION FILTER
# ==========================================================

def filter_items(items, category, occasion):
    """
    Returns items of the requested category.

    Priority:
    1. Exact occasion
    2. Casual
    3. Any item of that category
    """

    exact = [
        item
        for item in items
        if item.category == category
        and item.occasion == occasion
    ]

    if exact:
        return exact

    casual = [
        item
        for item in items
        if item.category == category
        and item.occasion == "Casual"
    ]

    if casual:
        return casual

    return [
        item
        for item in items
        if item.category == category
    ]


# ==========================================================
# WEATHER → SEASON SCORE
# ==========================================================

WEATHER_SEASON = {

    "Sunny": "Summer",

    "Rainy": "Rainy",

    "Cold": "Winter",

    "Cloudy": "All Season"

}


def season_score(item, weather):

    if item is None:
        return 0

    if item.season == "All Season":
        return 10

    expected = WEATHER_SEASON.get(weather)

    if item.season == expected:
        return 20

    return 0


# ==========================================================
# OCCASION SCORE
# ==========================================================

def occasion_score(item, occasion):

    if item is None:
        return 0

    if item.occasion == occasion:
        return 15

    if item.occasion == "Casual":
        return 8

    return 0


# ==========================================================
# COLOR SCORE
# ==========================================================

def color_score(first, second):

    if first is None or second is None:
        return 0

    if colors_match(first.color, second.color):
        return 15

    return 0


# ==========================================================
# BAG SELECTION
# ==========================================================

def choose_best_bag(bags, reference_color):

    if not bags:
        return None

    for bag in bags:

        if colors_match(reference_color, bag.color):
            return bag

    return bags[0]


# ==========================================================
# ACCESSORY SELECTION
# ==========================================================

def choose_best_accessory(accessories, reference_color):

    if not accessories:
        return None

    for accessory in accessories:

        if colors_match(reference_color, accessory.color):
            return accessory

    return accessories[0]

    # ==========================================================
# SCORE COMPLETE OUTFIT
# ==========================================================

def score_outfit(

    top=None,
    bottom=None,
    dress=None,
    shoes=None,
    bag=None,
    accessory=None,

    occasion=None,
    weather=None

):

    score = 0

    breakdown = {

        "color":0,
        "occasion":0,
        "weather":0,
        "style":0

    }


    # =====================================================
    # OCCASION
    # =====================================================

    outfit_items = [

        top,
        bottom,
        dress,
        shoes,
        bag,
        accessory

    ]

    for item in outfit_items:

        value = occasion_score(

            item,

            occasion

        )

        breakdown["occasion"] += value

        score += value


    breakdown["occasion"] = min(

        breakdown["occasion"],

        30

    )


    # =====================================================
    # WEATHER / SEASON
    # =====================================================

    weather_items = [

        top,
        bottom,
        dress,
        shoes

    ]

    for item in weather_items:

        value = season_score(

            item,

            weather

        )

        breakdown["weather"] += value

        score += value


    breakdown["weather"] = min(

        breakdown["weather"],

        20

    )


    # =====================================================
    # COLOR HARMONY
    # =====================================================

    if dress:

        score += color_score(

            dress,

            shoes

        )

        breakdown["color"] += color_score(

            dress,

            shoes

        )


        score += color_score(

            dress,

            bag

        )

        breakdown["color"] += color_score(

            dress,

            bag

        )


        score += color_score(

            dress,

            accessory

        )

        breakdown["color"] += color_score(

            dress,

            accessory

        )

    else:

        score += color_score(

            top,

            bottom

        )

        breakdown["color"] += color_score(

            top,

            bottom

        )


        score += color_score(

            bottom,

            shoes

        )

        breakdown["color"] += color_score(

            bottom,

            shoes

        )


        score += color_score(

            top,

            bag

        )

        breakdown["color"] += color_score(

            top,

            bag

        )


        score += color_score(

            top,

            accessory

        )

        breakdown["color"] += color_score(

            top,

            accessory

        )


    breakdown["color"] = min(

        breakdown["color"],

        40

    )


    # =====================================================
    # STYLE BONUS
    # =====================================================

    style_bonus = 10

    if bag:

        style_bonus += 5

    if accessory:

        style_bonus += 5


    breakdown["style"] = style_bonus

    score += style_bonus


    score = min(score,100)


    return score, breakdown


# ==========================================================
# BUILD AI REASON
# ==========================================================

def build_reason(outfit, occasion, weather):

    if outfit.get("Dress"):

        dress = outfit["Dress"]

        return (

            f"The {dress.name} is an excellent choice for "

            f"{occasion.lower()} occasions. "

            f"It suits {weather.lower()} weather and pairs "

            f"well with the selected accessories to create "

            f"a balanced, elegant outfit."

        )


    top = outfit["Top"]

    bottom = outfit["Bottom"]

    shoes = outfit["Shoes"]


    return (

        f"The {top.name} complements the "

        f"{bottom.name} through a harmonious color "

        f"combination. The {shoes.name} completes the look, "

        f"making it appropriate for {occasion.lower()} "

        f"wear in {weather.lower()} conditions."

    )


    # ==========================================================
# GENERATE ALL POSSIBLE OUTFITS
# ==========================================================

def generate_outfits(items, occasion, weather):

    tops = filter_items(
        items,
        "Top",
        occasion
    )

    bottoms = filter_items(
        items,
        "Bottom",
        occasion
    )

    dresses = filter_items(
        items,
        "Dress",
        occasion
    )

    shoes = filter_items(
        items,
        "Shoes",
        occasion
    )

    bags = filter_items(
        items,
        "Bag",
        occasion
    )

    accessories = filter_items(
        items,
        "Accessory",
        occasion
    )

    outfits = []


    # =====================================================
    # DRESS OUTFITS
    # =====================================================

    for dress in dresses:

        for shoe in shoes:

            bag = choose_best_bag(
                bags,
                dress.color
            )

            accessory = choose_best_accessory(
                accessories,
                dress.color
            )

            score, breakdown = score_outfit(

                dress=dress,

                shoes=shoe,

                bag=bag,

                accessory=accessory,

                occasion=occasion,

                weather=weather

            )

            outfits.append({

                "Dress": dress,

                "Shoes": shoe,

                "Bag": bag,

                "Accessory": accessory,

                "score": score,

                "breakdown": breakdown,

                "reason": build_reason({

                    "Dress": dress,

                    "Shoes": shoe,

                    "Bag": bag,

                    "Accessory": accessory

                }, occasion, weather)

            })


    # =====================================================
    # TOP + BOTTOM OUTFITS
    # =====================================================

    for top, bottom, shoe in itertools.product(

        tops,

        bottoms,

        shoes

    ):

        if top.id == bottom.id:
            continue

        bag = choose_best_bag(
            bags,
            top.color
        )

        accessory = choose_best_accessory(
            accessories,
            top.color
        )

        score, breakdown = score_outfit(

            top=top,

            bottom=bottom,

            shoes=shoe,

            bag=bag,

            accessory=accessory,

            occasion=occasion,

            weather=weather

        )

        outfits.append({

            "Top": top,

            "Bottom": bottom,

            "Shoes": shoe,

            "Bag": bag,

            "Accessory": accessory,

            "score": score,

            "breakdown": breakdown,

            "reason": build_reason({

                "Top": top,

                "Bottom": bottom,

                "Shoes": shoe,

                "Bag": bag,

                "Accessory": accessory

            }, occasion, weather)

        })


    outfits.sort(

        key=lambda outfit: outfit["score"],

        reverse=True

    )

    return outfits

    # ==========================================================
# REMOVE DUPLICATE OUTFITS
# ==========================================================

def remove_duplicate_outfits(outfits):

    unique = []

    used_combinations = set()

    used_tops = set()
    used_bottoms = set()
    used_dresses = set()

    for outfit in outfits:

        # -------------------------------
        # Dress outfit
        # -------------------------------

        if outfit.get("Dress"):

            dress = outfit["Dress"]

            shoe = outfit.get("Shoes")

            key = (

                dress.id,

                shoe.id if shoe else 0

            )

            if key in used_combinations:
                continue

            if dress.id in used_dresses:
                continue

            used_dresses.add(dress.id)

            used_combinations.add(key)

            unique.append(outfit)

            continue


        # -------------------------------
        # Top + Bottom outfit
        # -------------------------------

        top = outfit["Top"]

        bottom = outfit["Bottom"]

        shoe = outfit.get("Shoes")

        key = (

            top.id,

            bottom.id,

            shoe.id if shoe else 0

        )

        if key in used_combinations:
            continue

        # Try to avoid repeating the same top
        if top.id in used_tops:

            continue

        # Try to avoid repeating the same bottom
        if bottom.id in used_bottoms:

            continue

        used_tops.add(top.id)

        used_bottoms.add(bottom.id)

        used_combinations.add(key)

        unique.append(outfit)

    return unique


# ==========================================================
# RETURN BEST 3 RECOMMENDATIONS
# ==========================================================

def choose_best_outfits(items, occasion, weather):

    outfits = generate_outfits(

        items,

        occasion,

        weather

    )

    outfits = remove_duplicate_outfits(

        outfits

    )

    if len(outfits) >= 3:

        return outfits[:3]

    # -----------------------------------------------------
    # Not enough unique outfits?
    # Fill remaining slots using the highest-scoring
    # outfits that weren't already selected.
    # -----------------------------------------------------

    all_outfits = generate_outfits(

        items,

        occasion,

        weather

    )

    existing = []

    for outfit in outfits:

        if outfit.get("Dress"):

            existing.append(

                ("Dress", outfit["Dress"].id)

            )

        else:

            existing.append(

                (

                    outfit["Top"].id,

                    outfit["Bottom"].id,

                    outfit["Shoes"].id

                )

            )

    for outfit in all_outfits:

        if len(outfits) == 3:

            break

        if outfit.get("Dress"):

            key = (

                "Dress",

                outfit["Dress"].id

            )

        else:

            key = (

                outfit["Top"].id,

                outfit["Bottom"].id,

                outfit["Shoes"].id

            )

        if key in existing:

            continue

        outfits.append(outfit)

        existing.append(key)

    return outfits

