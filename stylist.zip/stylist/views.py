from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from wardrobe.models import ClothingItem

from .recommendation import choose_best_outfits



@login_required
def stylist(request):

    recommendations = []

    occasion = ""
    weather = ""

    error_title = ""
    error_message = ""


    if request.method == "POST":


        occasion = request.POST.get(
            "occasion",
            ""
        )


        weather = request.POST.get(
            "weather",
            ""
        )


        clothes = ClothingItem.objects.filter(
            user=request.user
        )



        # --------------------------
        # EMPTY WARDROBE
        # --------------------------

        if not clothes.exists():

            error_title = "👗 Wardrobe Empty"

            error_message = (
                "Your wardrobe does not contain any clothing items. "
                "Upload clothes first to get AI recommendations."
            )


        else:


            outfits = choose_best_outfits(
                clothes,
                occasion,
                weather
            )



            # --------------------------
            # NO OUTFIT FOUND
            # --------------------------

            if not outfits:


                error_title = "😔 No Suitable Outfit Found"


                error_message = (
                    f"We couldn't find a perfect {occasion} outfit "
                    f"for {weather.lower()} weather."
                    "\n\nTry uploading more clothes or different styles."
                )



            else:



                titles = [

                    "🥇 Best Match",

                    "🌟 Alternative Style",

                    "🔥 Trendy Choice"

                ]



                for index, outfit in enumerate(outfits):


                    outfit_details = {}



                    categories = [

                        "Top",
                        "Bottom",
                        "Dress",
                        "Shoes",
                        "Bag",
                        "Accessory"

                    ]



                    for category in categories:


                        item = outfit.get(category)



                        if item:


                            outfit_details[category] = {


                                "name":
                                    item.name,


                                "color":
                                    item.color,


                                "brand":
                                    item.brand,


                                "season":
                                    item.season,


                                "occasion":
                                    item.occasion,


                                "image":
                                    item.image.url
                                    if item.image
                                    else ""

                            }




                    recommendations.append({


                        "title":

                            titles[index]
                            if index < len(titles)
                            else f"Outfit {index+1}",



                        "score":

                            outfit.get(
                                "score",
                                0
                            ),



                        "reason":

                            outfit.get(
                                "reason",
                                "AI selected this outfit based on your wardrobe."
                            ),



                        "breakdown":

                            outfit.get(
                                "breakdown",
                                {}
                            ),



                        "items":

                            outfit_details


                    })





    return render(

        request,

        "stylist.html",

        {


            "recommendations":

                recommendations,


            # Keep selected values after submit

            "selected_occasion":

                occasion,


            "selected_weather":

                weather,



            "error_title":

                error_title,



            "error_message":

                error_message,


        }

    )